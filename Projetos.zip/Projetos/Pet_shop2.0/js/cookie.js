document.addEventListener('DOMContentLoaded', function () {
    // Verificar se o aviso de cookies já foi aceito
    if (localStorage.getItem('cookieAccepted') !== 'true') {
        // Se não foi aceito, exibir o aviso
        showCookieNotice();
    }
});

function showCookieNotice() {
    var cookieNotice = document.getElementById('cookie-notice');
    cookieNotice.style.display = 'block';
}

function hideCookieNotice() {
    var cookieNotice = document.getElementById('cookie-notice');
    cookieNotice.style.display = 'none';

    // Marcar que o aviso foi aceito
    localStorage.setItem('cookieAccepted', 'true');
}
