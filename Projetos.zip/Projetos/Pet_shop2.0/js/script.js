let options = document.querySelector(".options");

        function menuMobile(){
            options.classList.toggle("active");
        }

        document.getElementById('myForm').addEventListener('submit', function (e) {
            // Impedir o envio padrão do formulário
            e.preventDefault();
    
            // Redirecionar para a nova tela (index.html neste exemplo)
            window.location.href = 'pagina_inicial.html';
        });


    
  // Exemplo de como você pode preencher dinamicamente a galeria de pets
document.addEventListener('DOMContentLoaded', function () {
  const petGallery = document.getElementById('pet-gallery');

  // Exemplo de dados fictícios (substitua com dados reais)
  const petsData = [
      { name: 'Fido', species: 'Dog', image: 'link_para_imagem_fido.jpg' },
      { name: 'Whiskers', species: 'Cat', image: 'link_para_imagem_whiskers.jpg' },
      // Adicione mais pets conforme necessário
  ];

  petsData.forEach(pet => {
      const petCard = document.createElement('div');
      petCard.classList.add('pet-card');

      const petImage = document.createElement('img');
      petImage.src = pet.image;
      petImage.alt = pet.name;

      const petName = document.createElement('h3');
      petName.textContent = pet.name;

      const petSpecies = document.createElement('p');
      petSpecies.textContent = pet.species;

      petCard.appendChild(petImage);
      petCard.appendChild(petName);
      petCard.appendChild(petSpecies);

      petGallery.appendChild(petCard);
  });
});


// Adicione esta função ao seu arquivo script.js existente

function openAdoptionForm(petName) {
    // Lógica para abrir a tela de cadastro (pode ser um modal, uma nova página, etc.)
    alert(`Você está prestes a iniciar o processo de adoção para ${petName || 'um pet'}.`);
    // Adicione a lógica real de abertura da tela de cadastro conforme necessário.
}

// Adicione estas funções ao seu arquivo script.js existente

function openAdoptionForm(petName) {
    const modal = document.getElementById('adoption-modal');
    const petNameField = document.getElementById('adopt-pet-name');

    // Preencha o nome do pet no formulário
    petNameField.value = petName || '';

    // Exiba o modal
    modal.style.display = 'block';
}

function closeAdoptionForm() {
    const modal = document.getElementById('adoption-modal');
    modal.style.display = 'none';
}

// Fecha o modal se o usuário clicar fora dele
window.onclick = function (event) {
    const modal = document.getElementById('adoption-modal');
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}

/* Menu botao */

function toggleSidebar() {
    var sidebar = document.getElementById('sidebar');
    if (sidebar.style.width === '250px') {
      sidebar.style.width = '0';
    } else {
      sidebar.style.width = '150px';
    }
  }

  function closeSidebar() {
    document.getElementById('sidebar').style.width = '0';
  }


  /** portfolio */

  /**doação */

  function submitDonation() {
    // Lógica de processamento da doação (simulado aqui)
    setTimeout(function() {
        document.getElementById("donationForm").reset();
        document.getElementById("confirmationMessage").classList.remove("hidden");
    }, 1000);
}


/**button Entrar */

document.getElementById('entrarBtn').addEventListener('click', function() {
  // Aqui você pode adicionar a lógica para realizar o login

  // Exemplo: exibindo a notificação
  alert('Login Realizado com sucesso');
});

  // Bolhas


document.addEventListener("DOMContentLoaded", () => {
  const love = document.querySelector('.love');
  const numBubbles = 20;
  const bubbleMinSize = 10;
  const bubbleMaxSize = 50;

  for (let i = 0; i < numBubbles; i++) {
      const bubble = document.createElement('div');
      bubble.classList.add('bubble');

      const size = Math.random() * (bubbleMaxSize - bubbleMinSize) + bubbleMinSize;
      bubble.style.width = `${size}px`;
      bubble.style.height = `${size}px`;

      bubble.style.left = `${Math.random() * 100}vw`;
      bubble.style.bottom = `-50px`;  // Start below the viewport

      bubble.style.animationDuration = `${Math.random() * 5 + 5}s`;
      bubble.style.animationDelay = `${Math.random() * 5}s`;

      love.appendChild(bubble);
  }
});
