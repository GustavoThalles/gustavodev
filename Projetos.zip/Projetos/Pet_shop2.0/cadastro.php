<?php
// Conexão com o banco de dados
$servername = "localhost";
$username = "seu_usuario";
$password = "sua_senha";
$dbname = "seu_banco_de_dados";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Recebe os dados do formulário
$email = $_POST['email'];
$senha = $_POST['password'];
$telefone = $_POST['adopt-phone'];
$estado = $_POST['state'];
$cidade = $_POST['city'];

// Insere os dados no banco de dados
$sql = "INSERT INTO usuarios (email, senha, telefone, estado, cidade)
VALUES ('$email', '$senha', '$telefone', '$estado', '$cidade')";

if ($conn->query($sql) === TRUE) {
    echo "Cadastro realizado com sucesso!";
} else {
    echo "Erro ao cadastrar: " . $conn->error;
}

$conn->close();
?>
